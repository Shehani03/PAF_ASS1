package org.restapi.crud.crud.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.restapi.crud.crud.model.crudmodel;



public class crudservice {
	
	Connection con;
	
	public crudservice() {
	
	try {
		String url = String.format("jdbc:mysql://localhost:3306/user");
		String uname = "root";
		String pwd = "";

					Class.forName("con.mysql.cj.jdbc.Driver");
					con =DriverManager.getConnection(url,uname,pwd);
		
	} catch(Exception e) {
		System.out.println(e +"data insert unsuccess.");
		
	}
}

	
	public crudmodel insertPayment1(crudmodel user) {
		String insert = "insert into person(name,age) values(?,?) ";
		
		try {
			PreparedStatement ps = con.prepareStatement(insert);
			ps.setString(1, user.getName());
			ps.setLong(2, user.getAge());
			
			
			ps.execute();
			}catch(Exception e) {
				System.out.println(e +"data insert unsuccess.");
				
			}
			return user;	
		}
		
	
	public ArrayList<crudmodel> getUserById(int id) throws SQLException{
			
		
	    ArrayList<crudmodel>data = new ArrayList<crudmodel>();
		String select = "select * from person where id =?";
		PreparedStatement ps = con.prepareStatement(select);
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()) {
			crudmodel model = new crudmodel();
			
			model.setName(rs.getString("name")); // column name
			model.setAge(rs.getInt("age"));
			data.add(model);
			
	}
		return data;
	
	}
	
	public crudmodel updatePayment1(crudmodel user) {
		String insert = "update person set name=? , age=?  where id =?";
		
		try {
			PreparedStatement ps = con.prepareStatement(insert);
			ps.setString(1, user.getName());
			ps.setLong(2, user.getAge());
			ps.setInt(3, user.getId());
			
			
			ps.executeUpdate();
			}catch(Exception e) {
				System.out.println(e +"data insert unsuccess.");
				
			}
			return user;	
		}


	public int deletePayment1(int id) {
		String insert = "delete from person where id =?";
		
		try {
			PreparedStatement ps = con.prepareStatement(insert);
			ps.setInt(1,id);
			
			ps.executeUpdate();
			}catch(Exception e) {
				System.out.println(e +"data insert unsuccess.");
				
			}
			return id;	
		}


	public ArrayList<crudmodel> getPayment() {
		// TODO Auto-generated method stub
		return null;
	}


	public ArrayList<crudmodel> getPaymentById(int id) {
		// TODO Auto-generated method stub
		return null;
	}


	public crudmodel updatePayment(crudmodel user) {
		// TODO Auto-generated method stub
		return null;
	}


	public int deletePayment(int id) {
		// TODO Auto-generated method stub
		return 0;
	}


	public crudmodel insertPayment(crudmodel payment) {
		// TODO Auto-generated method stub
		return null;
	}


	


	}
	



